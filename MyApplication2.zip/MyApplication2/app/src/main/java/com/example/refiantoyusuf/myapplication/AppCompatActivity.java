package com.example.refiantoyusuf.myapplication;

import android.os.Bundle;

/**
 * Created by RefiantoYusuf on 13/02/2018.
 */

class AppCompatActivity {
    public void onCreate(Bundle savedInstanceState) {
    }
}
